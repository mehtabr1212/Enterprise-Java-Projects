import java.io.IOException;
import java.io.PrintWriter; 
import javax.servlet.annotation.*;
import javax.servlet.http.*;
import javax.servlet.ServletException;
import java.sql.*;

@WebServlet("/AdminLoginServlet")
public class AdminLoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        // Retrieve the admin username and password from the form
        String adminUsername = request.getParameter("adminUsername");
        String adminPassword = request.getParameter("adminPassword");

        // Flag to check login success
        boolean loginSuccess = false;

        // Database connection
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            // Load JDBC Driver
            Class.forName("org.apache.derby.jdbc.ClientDriver"); // Correct driver for Derby

            // Establish connection to the database
            connection = DriverManager.getConnection("jdbc:derby://localhost:1527/Tournament", "app", "app");

            // SQL query to verify admin login
            String sql = "SELECT * FROM admins WHERE username = ? AND password = ?";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, adminUsername);
            preparedStatement.setString(2, adminPassword); // Note: Passwords should be hashed in production
            
            resultSet = preparedStatement.executeQuery();

            // If the result set has data, login is successful
            if (resultSet.next()) {
                loginSuccess = true;
            }

        } catch (ClassNotFoundException | SQLException e) {
            out.println("Error: " + e.getMessage());
            response.sendRedirect("signin.jsp?error=An error occurred during login");
        } finally {
            // Close all connections
            try {
                if (resultSet != null) resultSet.close();
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                out.println("Error closing resources: " + e.getMessage());
            }
        }

        // Redirect user based on login success or failure
        if (loginSuccess) {
            // Redirect to the admin dashboard
            response.sendRedirect("adminDashboard.jsp");
        } else {
            // Redirect back to sign-in page with an error message
            response.sendRedirect("signin.jsp?error=Invalid username or password");
        }
    }
}
