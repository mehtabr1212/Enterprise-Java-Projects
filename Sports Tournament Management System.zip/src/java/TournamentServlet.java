import java.io.IOException;
import java.io.PrintWriter; 
import javax.servlet.annotation.*;
import javax.servlet.http.*;
import javax.servlet.ServletException;
import java.sql.*; 

@WebServlet(urlPatterns = {"/TournamentServlet"})
public class TournamentServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String name = request.getParameter("name");
        String location = request.getParameter("location");
        String startDate = request.getParameter("start_date");
        String endDate = request.getParameter("end_date");
        String sports_names = request.getParameter("sports_names");

        try {
            
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            Connection c=DriverManager.getConnection("jdbc:derby://localhost:1527/Tournament","app","app");
            
            PreparedStatement stmt = c.prepareStatement("INSERT INTO tournaments (name, location, start_date, end_date, sports_names) VALUES (?, ?, ?, ?, ?)");
            stmt.setString(1, name);
            stmt.setString(2, location);
            stmt.setDate(3, Date.valueOf(startDate));
            stmt.setDate(4, Date.valueOf(endDate));
            stmt.setString(5, sports_names);
            stmt.executeUpdate();
            c.close();
            response.sendRedirect("tournaments.jsp");
        }
        catch (Exception e) {
            out.println(e);
        }
    }
}
