import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.annotation.*;
import javax.servlet.http.*;
import javax.servlet.ServletException;
import java.sql.*;

@WebServlet(urlPatterns = {"/SignupServlet"})
public class SignupServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        // Get form parameters from the signup form
        String username = request.getParameter("username");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String confirmPassword = request.getParameter("confirmPassword");

        // Validate the form input
        if (!password.equals(confirmPassword)) {
            // Redirect to signup page with error if passwords don't match
            response.sendRedirect("signup.jsp?error=Passwords do not match");
            return;
        }

        // Database connection details
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            // Load JDBC Driver
            Class.forName("org.apache.derby.jdbc.ClientDriver");

            // Establish connection to the database
            connection = DriverManager.getConnection("jdbc:derby://localhost:1527/Tournament", "app", "app");

            // SQL query to insert admin data into the database
            String sql = "INSERT INTO admins (username, email, password) VALUES (?, ?, ?)";

            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, email);
            preparedStatement.setString(3, password); // Note: Passwords should be hashed in production

            // Execute the insert query
            int result = preparedStatement.executeUpdate();

            if (result > 0) {
                // Signup successful, redirect to the sign-in page
                response.sendRedirect("signin.jsp");
            } else {
                // If something goes wrong, redirect back to the signup page with an error
                response.sendRedirect("signup.jsp?error=Signup failed, please try again");
            }

        } catch (ClassNotFoundException | SQLException e) {
            out.println("Error: " + e.getMessage());
            // Log the error and redirect back to the signup page with a generic error
            response.sendRedirect("signup.jsp?error=An error occurred during signup");
        } finally {
            // Close all database connections
            try {
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                out.println("Error closing resources: " + e.getMessage());
            }
        }
    }
}
