import java.io.IOException;
import java.io.PrintWriter; 
import javax.servlet.annotation.*;
import javax.servlet.http.*;
import javax.servlet.ServletException;
import java.sql.*;

@WebServlet("/TeamServlet")
public class TeamServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String teamName = request.getParameter("team_name");
        int tournamentId = Integer.parseInt(request.getParameter("tournament_id"));

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            Connection c=DriverManager.getConnection("jdbc:derby://localhost:1527/Tournament","app","app");
            
            PreparedStatement stmt = c.prepareStatement("INSERT INTO teams (team_name, tournament_id) VALUES (?, ?)");
            stmt.setString(1, teamName);
            stmt.setInt(2, tournamentId);
            stmt.executeUpdate();
            c.close();
            response.sendRedirect("teams.jsp");
        }
        catch (Exception e) {
            out.println(e);
        }
    }
}

