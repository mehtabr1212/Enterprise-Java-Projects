import java.io.IOException;
import java.io.PrintWriter; 
import javax.servlet.annotation.*;
import javax.servlet.http.*;
import javax.servlet.ServletException;
import java.sql.*;

@WebServlet(urlPatterns = {"/DeleteTournamentServlet"})
public class DeleteTournamentServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        String name= request.getParameter("name");

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            Connection connection = DriverManager.getConnection("jdbc:derby://localhost:1527/Tournament", "app", "app");
            
            PreparedStatement stmt = connection.prepareStatement("DELETE FROM tournaments WHERE name = ?");
            stmt.setString(1, name);
            int rowsAffected = stmt.executeUpdate();
            connection.close();
            
            if (rowsAffected > 0) {
                response.sendRedirect("tournaments.jsp");
            } else {
                response.sendRedirect("DeleteTournament.jsp?error=Tournament not found");
            }
        } catch (Exception e) {
            out.println("Error: " + e.getMessage());
        }
    }
}
